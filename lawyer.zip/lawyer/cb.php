<?php 

$phone=$_POST['pn'];



mail("Andrej.Shadrin.87@mail.ru","Обратный звонок",$phone);
?>