$(document).ready(function(){
    
   
    
    
    $(".b1").hover(function(){
        $(".h1").animate({
            top:"-10px"
        },900);
        setTimeout(function(){
            $(".link1").fadeIn(800);
        },800);
        
    },function(){

         setTimeout(function(){
            $(".con h1").animate({
            top:"0px"
        },900);
        },800);
         $(".link1").fadeOut(800);
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});